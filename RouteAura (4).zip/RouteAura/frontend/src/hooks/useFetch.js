import { useCallback, useEffect, useRef, useState } from 'react';
import { get, errMsg } from '../services/api';

/** Loads GET `url` with `params`; re-runs when they change. Returns { data, loading, error, reload }. */
export default function useFetch(url, params, { skip = false } = {}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(!skip);
  const [error, setError] = useState(null);
  const key = JSON.stringify([url, params]);
  const seq = useRef(0);

  const run = useCallback(async (silent = false) => {
    if (skip || !url) return;
    const n = ++seq.current;
    if (!silent) setLoading(true);
    try {
      const d = await get(url, params);
      if (n === seq.current) { setData(d); setError(null); }
    } catch (e) {
      if (n === seq.current) setError(errMsg(e));
    } finally {
      if (n === seq.current) setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, skip]);

  useEffect(() => { run(); }, [run]);
  return { data, loading, error, reload: () => run(true), setData };
}
