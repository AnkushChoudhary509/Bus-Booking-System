import { Route, BoardingPoint, Journey } from '../models/index.js';
import { AppError, asyncHandler, ok } from '../utils/AppError.js';
import { endpoints } from '../services/roadRouteService.js';

const ci = { locale: 'en', strength: 2 };

export const cities = asyncHandler(async (req, res) => {
  const [a, b] = await Promise.all([Route.distinct('source', { isActive: true }), Route.distinct('destination', { isActive: true })]);
  ok(res, { cities: [...new Set([...a, ...b])].sort() });
});

export const list = asyncHandler(async (req, res) => {
  const filter = req.user?.role === 'admin' ? {} : { isActive: true };
  ok(res, { routes: await Route.find(filter).sort({ source: 1, destination: 1 }) });
});

/** Featured routes for the landing page: routes with the most upcoming scheduled journeys. */
export const featured = asyncHandler(async (req, res) => {
  const agg = await Journey.aggregate([
    { $match: { status: 'scheduled', departure: { $gt: new Date() } } },
    { $group: { _id: '$route', journeys: { $sum: 1 }, minFare: { $min: '$baseFare' } } },
    { $sort: { journeys: -1 } },
    { $limit: 8 },
  ]);
  const routes = await Route.find({ _id: { $in: agg.map((a) => a._id) } }).lean();
  const byId = new Map(routes.map((r) => [String(r._id), r]));
  ok(res, {
    routes: agg
      .map((a) => ({ ...byId.get(String(a._id)), upcomingJourneys: a.journeys, startingFare: a.minFare }))
      .filter((r) => r._id),
  });
});

export const getOne = asyncHandler(async (req, res) => {
  const route = await Route.findById(req.params.id);
  if (!route) throw new AppError('Route not found', 404);
  ok(res, { route });
});

export const create = asyncHandler(async (req, res) => {
  const existing = await Route.findOne({ source: req.body.source, destination: req.body.destination }).collation(ci);
  if (existing) return ok(res, { route: existing, existing: true }, 'Route already exists');
  // fill in coordinates for known cities so the tracking map can draw the road
  const ends = endpoints(req.body);
  const body = { ...req.body, ...(ends && { sourceCoords: req.body.sourceCoords || ends.a, destinationCoords: req.body.destinationCoords || ends.b }) };
  ok(res, { route: await Route.create(body) }, 'Route created', 201);
});

export const update = asyncHandler(async (req, res) => {
  const route = await Route.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!route) throw new AppError('Route not found', 404);
  ok(res, { route }, 'Route updated');
});

export const deactivate = asyncHandler(async (req, res) => {
  const upcoming = await Journey.exists({ route: req.params.id, status: { $in: ['scheduled', 'boarding', 'running', 'delayed'] } });
  if (upcoming) throw new AppError('Cancel or complete the journeys on this route first', 409);
  const route = await Route.findByIdAndUpdate(req.params.id, { isActive: req.query.activate === 'true' }, { new: true });
  if (!route) throw new AppError('Route not found', 404);
  ok(res, { route });
});

export const listPoints = asyncHandler(async (req, res) => {
  const filter = { route: req.params.id };
  if (req.user?.role === 'operator' && req.operator && req.query.mine === 'true') filter.operator = req.operator._id;
  if (req.query.kind) filter.kind = req.query.kind;
  ok(res, { points: await BoardingPoint.find(filter).sort({ kind: 1, offsetMin: 1 }) });
});

export const createPoint = asyncHandler(async (req, res) => {
  if (!req.operator) throw new AppError('Only operators can add boarding points', 403);
  const route = await Route.findById(req.params.id);
  if (!route) throw new AppError('Route not found', 404);
  const point = await BoardingPoint.create({ ...req.body, route: route._id, operator: req.operator._id });
  ok(res, { point }, 'Point added', 201);
});

export const deletePoint = asyncHandler(async (req, res) => {
  const point = await BoardingPoint.findById(req.params.pointId);
  if (!point) throw new AppError('Point not found', 404);
  if (req.user.role !== 'admin' && String(point.operator) !== String(req.operator?._id)) throw new AppError('Not your boarding point', 403);
  if (await Journey.exists({ $or: [{ boardingPoints: point._id }, { droppingPoints: point._id }], status: { $in: ['scheduled', 'boarding', 'running', 'delayed'] } })) {
    throw new AppError('This point is used by an active journey', 409);
  }
  await point.deleteOne();
  ok(res, {}, 'Point removed');
});
