import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { api, loginAs, startDb, stopDb } from './helpers.js';
import { Journey } from '../models/index.js';

beforeAll(startDb);
afterAll(stopDb);

describe('live GPS driver mode', () => {
  it('rejects passengers and anonymous callers', async () => {
    const j = await Journey.findOne({ status: 'scheduled' });
    const pax = await loginAs('passenger@routeaura.test');
    expect((await api().post(`/api/v1/journeys/${j._id}/location`).send({ lat: 28.6, lng: 77.2 })).status).toBe(401);
    expect((await api().post(`/api/v1/journeys/${j._id}/location`).set(pax.auth).send({ lat: 28.6, lng: 77.2 })).status).toBe(403);
  });

  it('validates coordinates', async () => {
    const admin = await loginAs('admin@routeaura.test');
    const j = await Journey.findOne({ status: 'scheduled' });
    const r = await api().post(`/api/v1/journeys/${j._id}/location`).set(admin.auth).send({ lat: 999, lng: 0 });
    expect(r.status).toBe(400);
  });

  it('a fix switches tracking to live GPS and stopping falls back to the simulation', async () => {
    const admin = await loginAs('admin@routeaura.test');
    const j = await Journey.findOne({ status: 'scheduled' });
    const post = await api().post(`/api/v1/journeys/${j._id}/location`).set(admin.auth).send({ lat: 28.61, lng: 77.21, accuracyM: 12, speedKmh: 40 });
    expect(post.status).toBe(200);
    let t = (await api().get(`/api/v1/journeys/${j._id}/tracking`)).body.data;
    expect(t.trackingType).toBe('gps');
    expect(t.simulated).toBe(false);
    expect(t.map.positionSource).toBe('gps');
    expect(t.map.position.lat).toBeCloseTo(28.61, 4);

    await api().delete(`/api/v1/journeys/${j._id}/location`).set(admin.auth).expect(200);
    t = (await api().get(`/api/v1/journeys/${j._id}/tracking`)).body.data;
    expect(t.simulated).toBe(true);
    expect(t.map.positionSource).toBe('simulated');
  });

  it('a stale fix is ignored', async () => {
    const j = await Journey.findOne({ status: 'running' }) || (await Journey.findOne());
    await Journey.updateOne({ _id: j._id }, { $set: { 'gps.active': true, 'gps.lat': 1, 'gps.lng': 1, 'gps.updatedAt': new Date(Date.now() - 10 * 60 * 1000) } });
    const t = (await api().get(`/api/v1/journeys/${j._id}/tracking`)).body.data;
    expect(t.map?.positionSource ?? 'simulated').toBe('simulated');
  });
});
